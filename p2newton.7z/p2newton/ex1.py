########################
# exercicio um
########################

#recebe valor no teclado
nota1 = int(input('digite a nota um: '))
nota2 = int(input('digite a nota dois:' ))

#funcao para calculo de media                 
def media(nota1, nota2):
                  media = nota1/nota2
                  return media



#chamada da funcao
media(nota1, nota2)


#################
#exercicio dois
#################

import csv 
arquivo = open('series.csv', 'r') #abrir arquivo csv
arquivoo = open ('series_novas.csv','r') #abrir arquivo csv

linhaum = arquivo.read() #ler csv
linhadois = arquivoo.read() #ler csv

dicioum = csv.DictReader(arquivo) #ler como dicionario csv
diciodois = csv.DictReader(arquivoo) #ler como dicionario csv

              
def ex2(arquivo, arquivoo):
    listaum = []
    listadois = []
    for linha in linhaum:
        listaum.append(linhaum)
        print(listaum)
        return listaum
        break
    for li in linhadois:
        listadois.append(linhadois)
        print(linhadois)
        break

ex2(arquivo, arquivoo)
def ex5(listaum):
        listaum.popitem(linhaum,[3])
    

ex5 (ex2)
arquivo.close()
